import {CHANGE_INPUT_VALUE, ADD_LIST_ITEM, DELETE_LIST_ITEM, INIT_STATE} from './actionTypes'

const defaultState = {
    inputValue: '',
    list: []
}

export default (state=defaultState, action) => {
    const newState = JSON.parse(JSON.stringify(state))

    switch(action.type) {
        case CHANGE_INPUT_VALUE:
            newState.inputValue = action.value
            return newState

        case ADD_LIST_ITEM:
            newState.list = [...newState.list, state.inputValue]
            newState.inputValue = ''
            return newState

        case DELETE_LIST_ITEM:
            newState.list.splice(action.index, 1)
            return newState

        case INIT_STATE:
            console.log(action)
            newState.list = action.list
            return newState

        default:
            return state
    }
}