export const CHANGE_INPUT_VALUE = 'change_input_value'
export const ADD_LIST_ITEM = 'add_list_item'
export const DELETE_LIST_ITEM = 'delete_list_item'
export const INIT_STATE = 'init_state'

