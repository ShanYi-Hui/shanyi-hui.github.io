import React, { Fragment } from 'react'

const TodoUI = (props) => {
    return (
        <Fragment>
            <div>
                <label>备忘录：</label>
                <input type='text'
                    placeholder='Please enter content !'
                    value={props.inputValue}
                    onChange={props.inputChange}
                />
                <button onClick={props.addListItem}>添加</button>
            </div>
            <ul>
                {props.list.map((item,index) => {
                    return <li key={item} index={index} onClick={props.deleteListItem}>{item}</li>
                })}
            </ul>
        </Fragment>
    )
}

export default TodoUI