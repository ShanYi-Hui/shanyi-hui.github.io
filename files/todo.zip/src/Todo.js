import React, { Component } from 'react'
import axios from 'axios'

import TodoUI from './TodoUi'
import store from './store'
import {getInputChangeAction, getAddListItemAction, getDeleteListItemAction, initState} from './store/actionCreators'

class Todo extends Component {
    constructor(props) {
        super(props)
        this.state = store.getState()
        store.subscribe(this.storeChange)
    }
    
    render() {
        return (
            <TodoUI 
                inputValue = {this.state.inputValue}
                list = {this.state.list}
                inputChange = {this.inputChange}
                addListItem = {this.addListItem}
                deleteListItem = {this.deleteListItem}
            />
        )
    }

    componentDidMount() {
        axios.get('/list.json')
            .then((res) => {
                console.log(res)
                const action = initState(res.data)
                store.dispatch(action)
            })
            .catch((err) => {
                console.log(err)
            })
    }

    inputChange = (e) => {
        const action = getInputChangeAction(e.target.value)
        store.dispatch(action)
    }

    addListItem = () => {
        const action = getAddListItemAction()
        store.dispatch(action)
    }

    deleteListItem = (e) => {
        const action = getDeleteListItemAction(e.target.getAttribute('index'))
        store.dispatch(action)
    }

    storeChange = () => {
        this.setState(store.getState)
    }
}

export default Todo
